create procedure login(IN us varchar(50), IN password varchar(50))
  BEGIN
	SELECT *
    from usuario_tb
    where username = us and contrasenia = password;
END;

