create procedure consultaProducto(IN nombreproducto varchar(50))
  BEGIN
    SELECT * FROM producto_tb WHERE nombreproducto like concat('%',nombrep,'%');
  END;

