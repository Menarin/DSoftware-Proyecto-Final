create procedure nuevoCliente(IN newID varchar(10), IN newNombre varchar(50), IN newApellido varchar(50))
  BEGIN
	insert into cliente_tb values (newID, newNombre, newApellido);
END;

