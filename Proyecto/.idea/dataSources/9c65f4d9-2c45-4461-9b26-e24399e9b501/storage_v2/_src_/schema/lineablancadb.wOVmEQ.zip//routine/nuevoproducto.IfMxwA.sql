create procedure nuevoProducto(IN newArt    varchar(50), IN newModelo varchar(70), IN newDescrip varchar(250),
                               IN newPrecio float, IN newCantidad int)
  BEGIN

	insert into producto_tb values (NULL ,newArt,newModelo,newDescrip,newPrecio,newCantidad);

END;

