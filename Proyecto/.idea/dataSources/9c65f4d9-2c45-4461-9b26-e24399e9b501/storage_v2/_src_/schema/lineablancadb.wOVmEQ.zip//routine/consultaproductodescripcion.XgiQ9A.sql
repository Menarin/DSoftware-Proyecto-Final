create procedure consultaProductoDescripcion(IN descriproducto varchar(250))
  BEGIN
    SELECT * FROM producto_tb WHERE descriproducto like concat('%',descrp,'%');
  END;

